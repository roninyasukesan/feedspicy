import React, { useState } from 'react';
import { Search, MapPin, Star, Heart, MessageCircle, Instagram, Phone, Calendar, Award } from 'lucide-react';

function App() {
  const [showProfile, setShowProfile] = useState(false);
  const [selectedProfile, setSelectedProfile] = useState(null);

  const vipProfiles = [
    {
      id: 1,
      name: "Maria Silva",
      location: "São Paulo, SP",
      rating: 4.9,
      reviews: 156,
      price: "R$ 200",
      specialties: ["Massagem Terapêutica", "Drenagem Linfática"],
      images: [
        "https://images.unsplash.com/photo-1600334089648-b0d9d3028eb2?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1519823551278-64ac92734fb1?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1515377905703-c4788e51af15?w=800&auto=format&fit=crop"
      ],
      bio: "Especialista em massagem terapêutica com mais de 10 anos de experiência.",
      verified: true
    },
    {
      id: 2,
      name: "Ana Paula",
      location: "São Paulo, SP",
      rating: 4.8,
      reviews: 142,
      price: "R$ 180",
      specialties: ["Massagem Relaxante", "Reflexologia"],
      images: [
        "https://images.unsplash.com/photo-1519975565142-f0b0ed755757?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1507652313519-d4e9174996dd?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1552693673-1bf958298935?w=800&auto=format&fit=crop"
      ],
      bio: "Especializada em técnicas de relaxamento e bem-estar.",
      verified: true
    },
    {
      id: 3,
      name: "Carla Santos",
      location: "São Paulo, SP",
      rating: 4.7,
      reviews: 98,
      price: "R$ 220",
      specialties: ["Shiatsu", "Massagem Esportiva"],
      images: [
        "https://images.unsplash.com/photo-1537868393473-29e04e4d0c4b?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1519823551278-64ac92734fb1?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1515377905703-c4788e51af15?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1516549655169-df83a0774514?w=800&auto=format&fit=crop"
      ],
      bio: "Profissional certificada em massagem esportiva e shiatsu.",
      verified: true
    },
    {
      id: 4,
      name: "Patricia Lima",
      location: "São Paulo, SP",
      rating: 4.9,
      reviews: 167,
      price: "R$ 250",
      specialties: ["Massagem Modeladora", "Drenagem Linfática"],
      images: [
        "https://images.unsplash.com/photo-1519975565142-f0b0ed755757?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1507652313519-d4e9174996dd?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1552693673-1bf958298935?w=800&auto=format&fit=crop"
      ],
      bio: "Especialista em massagem modeladora e redução de medidas.",
      verified: true
    }
  ];

  const regularProfiles = [
    {
      id: 5,
      name: "Julia Costa",
      location: "São Paulo, SP",
      rating: 4.5,
      reviews: 45,
      price: "R$ 150",
      specialties: ["Massagem Relaxante", "Aromaterapia"],
      images: [
        "https://images.unsplash.com/photo-1515377905703-c4788e51af15?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1516549655169-df83a0774514?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1552693673-1bf958298935?w=800&auto=format&fit=crop"
      ],
      bio: "Massagista com foco em relaxamento e bem-estar.",
      verified: false
    },
    {
      id: 6,
      name: "Fernanda Oliveira",
      location: "São Paulo, SP",
      rating: 4.6,
      reviews: 78,
      price: "R$ 170",
      specialties: ["Quiropraxia", "Massagem Terapêutica"],
      images: [
        "https://images.unsplash.com/photo-1519975565142-f0b0ed755757?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1507652313519-d4e9174996dd?w=800&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1552693673-1bf958298935?w=800&auto=format&fit=crop"
      ],
      bio: "Profissional especializada em quiropraxia e massagem terapêutica.",
      verified: false
    }
  ];

  const stories = [
    {
      id: 1,
      name: "Promoção",
      image: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&auto=format&fit=crop"
    },
    {
      id: 2,
      name: "Novidades",
      image: "https://images.unsplash.com/photo-1515377905703-c4788e51af15?w=800&auto=format&fit=crop"
    },
    {
      id: 3,
      name: "Destaques",
      image: "https://images.unsplash.com/photo-1516549655169-df83a0774514?w=800&auto=format&fit=crop"
    },
    {
      id: 4,
      name: "Eventos",
      image: "https://images.unsplash.com/photo-1519975565142-f0b0ed755757?w=800&auto=format&fit=crop"
    }
  ];

  const ProfileCard = ({ profile, isVip }) => (
    <div 
      className="bg-white rounded-lg shadow-lg overflow-hidden cursor-pointer transform transition hover:scale-[1.02]"
      onClick={() => {
        setSelectedProfile(profile);
        setShowProfile(true);
      }}
    >
      <div className="relative">
        <div className="grid grid-cols-2 gap-1">
          {profile.images.slice(0, 4).map((img, idx) => (
            <img 
              key={idx} 
              src={img} 
              alt={`${profile.name} ${idx + 1}`}
              className="w-full h-40 object-cover"
            />
          ))}
        </div>
        {isVip && (
          <div className="absolute top-2 right-2 bg-yellow-400 text-xs font-bold px-2 py-1 rounded-full flex items-center">
            <Award size={14} className="mr-1" />
            VIP
          </div>
        )}
      </div>
      <div className="p-4">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-lg font-semibold">{profile.name}</h3>
          <Heart className="text-gray-400 hover:text-red-500 cursor-pointer" size={20} />
        </div>
        <div className="flex items-center text-sm text-gray-600 mb-2">
          <MapPin size={16} className="mr-1" />
          {profile.location}
        </div>
        <div className="flex items-center text-sm mb-2">
          <Star size={16} className="text-yellow-400 mr-1" />
          <span>{profile.rating}</span>
          <span className="mx-1">•</span>
          <span>{profile.reviews} avaliações</span>
        </div>
        <div className="text-sm font-semibold text-gray-800">
          A partir de {profile.price}
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm fixed w-full top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Instagram className="h-8 w-8 text-pink-500" />
              <span className="ml-2 text-xl font-semibold">WellnessSP</span>
            </div>
            <div className="flex items-center space-x-4">
              <button className="px-4 py-2 rounded-full bg-pink-500 text-white hover:bg-pink-600 transition">
                Anunciar
              </button>
              <button className="px-4 py-2 rounded-full border border-gray-300 hover:bg-gray-50 transition">
                Entrar
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20">
        {/* Search Bar */}
        <div className="relative max-w-2xl mx-auto mb-8">
          <input
            type="text"
            placeholder="Buscar por localização, especialidade..."
            className="w-full px-4 py-3 pl-12 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
          />
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
        </div>

        {/* Stories */}
        <div className="flex space-x-4 overflow-x-auto pb-4 mb-8">
          {stories.map(story => (
            <div key={story.id} className="flex flex-col items-center flex-shrink-0">
              <div className="w-16 h-16 rounded-full ring-2 ring-pink-500 p-1">
                <img
                  src={story.image}
                  alt={story.name}
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <span className="text-xs mt-1">{story.name}</span>
            </div>
          ))}
        </div>

        {/* VIP Profiles */}
        <h2 className="text-xl font-semibold mb-4">Destaques VIP</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {vipProfiles.map(profile => (
            <ProfileCard key={profile.id} profile={profile} isVip={true} />
          ))}
        </div>

        {/* Regular Profiles */}
        <h2 className="text-xl font-semibold mb-4">Profissionais</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {regularProfiles.map(profile => (
            <ProfileCard key={profile.id} profile={profile} isVip={false} />
          ))}
        </div>
      </main>

      {/* Profile Modal */}
      {showProfile && selectedProfile && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h2 className="text-2xl font-semibold">{selectedProfile.name}</h2>
                  <div className="flex items-center text-sm text-gray-600 mt-1">
                    <MapPin size={16} className="mr-1" />
                    {selectedProfile.location}
                  </div>
                </div>
                <button
                  onClick={() => setShowProfile(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-6">
                {selectedProfile.images.map((img, idx) => (
                  <img
                    key={idx}
                    src={img}
                    alt={`${selectedProfile.name} ${idx + 1}`}
                    className="w-full h-64 object-cover rounded-lg"
                  />
                ))}
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center">
                    <Star size={16} className="text-yellow-400 mr-1" />
                    <span>{selectedProfile.rating}</span>
                    <span className="mx-1">•</span>
                    <span>{selectedProfile.reviews} avaliações</span>
                  </div>
                  {selectedProfile.verified && (
                    <span className="text-green-500 flex items-center">
                      <Award size={16} className="mr-1" />
                      Verificada
                    </span>
                  )}
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Sobre</h3>
                  <p className="text-gray-600">{selectedProfile.bio}</p>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Especialidades</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedProfile.specialties.map((specialty, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1 bg-gray-100 rounded-full text-sm"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex space-x-4 pt-4">
                  <button className="flex-1 bg-pink-500 text-white py-2 rounded-lg hover:bg-pink-600 transition flex items-center justify-center">
                    <Calendar size={18} className="mr-2" />
                    Agendar
                  </button>
                  <button className="flex-1 border border-gray-300 py-2 rounded-lg hover:bg-gray-50 transition flex items-center justify-center">
                    <MessageCircle size={18} className="mr-2" />
                    Mensagem
                  </button>
                  <button className="flex-1 border border-gray-300 py-2 rounded-lg hover:bg-gray-50 transition flex items-center justify-center">
                    <Phone size={18} className="mr-2" />
                    Contato
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;